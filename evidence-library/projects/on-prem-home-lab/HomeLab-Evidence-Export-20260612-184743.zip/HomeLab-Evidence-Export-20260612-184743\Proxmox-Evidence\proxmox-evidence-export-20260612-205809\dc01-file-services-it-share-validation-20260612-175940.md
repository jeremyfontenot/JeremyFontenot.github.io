# DC01 File Services IT Share Validation

Generated: Fri Jun 12 05:59:43 PM CDT 2026

## Scope
Validated Windows Server file services using SMB share permissions, NTFS permissions, and AD security groups.

## Server
- VM ID: 200
- Hostname: DC01
- Domain: ad.jeremyfontenot.online
- Share: \\DC01\IT
- Local path: C:\Shares\IT

## AD Security Groups
- JFAD\GG-FS-IT-RW
  - Access: SMB Change + NTFS Modify
  - Validated user: sd.tech

- JFAD\GG-FS-IT-RO
  - Access: SMB Read + NTFS Read/Execute
  - Validated user: standard.user

## Validation Results
- PASS: File Server role installed or already present.
- PASS: SMB share \\DC01\IT created.
- PASS: SMB permissions validated.
- PASS: NTFS permissions validated.
- PASS: sd.tech created and read a file from WS01.
- PASS: standard.user read the share but could not create a file.

## Evidence Captured
- DC01 file services initial evidence:
  C:\Lab-Evidence\DC01-File-Services-IT-Share-20260612-154549

- DC01 NTFS correction evidence:
  C:\Lab-Evidence\DC01-File-Services-IT-Share-NTFS-Fix-20260612-154755

- WS01 read/write validation:
  C:\Lab-Evidence\WS01-IT-Share-RW-Validation-20260612-174438

- WS01 read-only validation:
  C:\Lab-Evidence\WS01-IT-Share-RO-Validation-20260612-175653

## Snapshot Created
- VM 200 snapshot:
  dc01-fileshare-it-ok
