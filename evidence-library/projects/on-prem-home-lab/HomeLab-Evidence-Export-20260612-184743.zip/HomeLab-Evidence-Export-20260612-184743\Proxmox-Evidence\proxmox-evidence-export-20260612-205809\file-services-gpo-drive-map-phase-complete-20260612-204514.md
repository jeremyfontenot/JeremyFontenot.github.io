# File Services and GPO Drive Mapping Phase Complete

## Lab
- Project: Jeremy Fontenot On-Prem Home Lab
- Domain: ad.jeremyfontenot.online
- Server: DC01
- Workstation: WS01
- Share: \\DC01\IT
- Mapped Drive: I:

## Completed Work
- Created IT SMB share on DC01.
- Created AD security groups for file-share access.
- Configured SMB permissions.
- Corrected and validated NTFS permissions.
- Validated sd.tech read/write access.
- Validated standard.user read-only access and write denial.
- Created GPO to map I: drive to \\DC01\IT.
- Validated GPO application on WS01.
- Validated mapped drive access as sd.tech.
- Validated mapped drive read-only/write-denied behavior as standard.user.
- Captured DC01 monitoring and logging evidence.
- Corrected DC01 Windows Time service synchronization.
- Backed up DC01 and WS01 after final validation.

## Key DC01 Evidence Folders
- C:\Lab-Evidence\DC01-File-Services-IT-Share-20260612-154549
- C:\Lab-Evidence\DC01-File-Services-IT-Share-NTFS-Fix-20260612-154755
- C:\Lab-Evidence\DC01-Monitoring-Logging-Evidence-20260612-194849
- C:\Lab-Evidence\DC01-Time-Service-Fix-20260612-195240
- C:\Lab-Evidence\DC01-GPO-IT-Drive-Map-20260612-180844

## Key WS01 Evidence Folders
- C:\Lab-Evidence\WS01-IT-Share-RW-Validation-20260612-174438
- C:\Lab-Evidence\WS01-IT-Share-RO-Validation-20260612-175653
- C:\Lab-Evidence\WS01-IT-Drive-Map-Validation-Retry-20260612-181740
- C:\Lab-Evidence\WS01-IT-Drive-Map-RO-Validation-20260612-182632

## Key Proxmox Evidence Files
- /root/lab-evidence/dc01-file-services-it-share-validation-20260612-175940.md
- /root/lab-evidence/proxmox-storage-thinpool-validation-20260612-180054.txt
- /root/lab-evidence/post-fileservices-backup-validation-20260612-180206.txt
- /root/lab-evidence/ws01-clean-post-reboot-backup-20260612-194236.txt
- /root/lab-evidence/dc01-time-service-fix-backup-retry-20260612-195524.txt
- /root/lab-evidence/gpo-it-drive-map-final-backup-20260612-202944.txt

## Final Backups
- DC01: vzdump-qemu-200-2026_06_12-20_29_46.vma.zst
- WS01: vzdump-qemu-300-2026_06_12-20_34_53.vma.zst

## Portfolio Skills Validated
- Windows Server file services
- SMB share administration
- NTFS permissions
- AD security group-based access control
- Group Policy creation and linking
- User-side GPO application
- Mapped drive deployment
- Least-privilege access validation
- Read/write versus read-only permission testing
- Windows event logging and audit evidence
- Domain Controller time service repair
- Proxmox VM backup validation
